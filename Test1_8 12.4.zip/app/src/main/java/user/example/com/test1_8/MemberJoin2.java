package user.example.com.test1_8;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Vector;

public class MemberJoin2 extends AppCompatActivity {

    String name="";
    String email="";
    String pw1="";
    String pw=""; //회원가입 비밀번호 재입력
    String result=""; //서버에서 성공적으로 가입했는지 확인
    String temp="";
    String serial_num="";
    String phone=""; //핸드폰 번호
    final Context context = this;
    private static final int REQUEST_SIGNUP = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_member_join2);
        findViewById(R.id.submit_btn).setOnClickListener(buttonClick);
        findViewById(R.id.backButton2).setOnClickListener(backbuttonClick);

        Intent intent = getIntent();
        phone = intent.getStringExtra("phone");
        serial_num = intent.getStringExtra("serial_num");

        }
    Button.OnClickListener backbuttonClick = new Button.OnClickListener() {
        public void onClick(View v) {
android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(MemberJoin2.this); // AlertDialog를 띄울 activity를 argument로 지정해야 한다.
            builder.setTitle("회원가입을 종료하시면 내용은 저장되지 않습니다"); // AlertDialog.builder를 통해 Title text를 입력
            builder.setPositiveButton("종료하기", new DialogInterface.OnClickListener() { // AlertDialog.Builder에 Positive Button을 생성
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(getApplicationContext(), Login1.class);
                    startActivityForResult(intent, REQUEST_SIGNUP);
                    finish(); // App.의 종료. Activity 생애 주기 참고
                }
            });
            builder.setNegativeButton("취소", new DialogInterface.OnClickListener() { // AlertDialog.Builder에 Negative Button을 생성
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //  returnVal.setText("앱을 종료하지 않고 돌아왔음");
                    dialog.dismiss(); // "아니오" button이 받은 DialogInterface를 dismiss 하여 MainView로 돌아감
                }
            });
            android.support.v7.app.AlertDialog dialog = builder.create(); // 위의 builder를 생성할 AlertDialog 객체 생성
            dialog.show(); // dialog를 화면에 뿌려 줌
            //Intent intent = new Intent(getApplicationContext(), Login1.class);
            //startActivityForResult(intent, REQUEST_SIGNUP);
            //finish();

        }
    };
    Button.OnClickListener buttonClick = new Button.OnClickListener(){
        public void onClick(View v){
            try {
                //ObjectMapper objectMapper = new ObjectMapper();
                //String json = objectMapper.writeValueAsString(param);

                //new HttpUtil().execute(json);
//                new HttpUtil().execute();
                name=((EditText)(findViewById(R.id.name))).getText().toString();
                email=((EditText)(findViewById(R.id.email))).getText().toString();
                pw1=((EditText)(findViewById(R.id.pw1))).getText().toString();
                phone =((EditText)(findViewById(R.id.phone))).getText().toString();
                pw=((EditText)(findViewById(R.id.pw))).getText().toString();
                serial_num=((EditText)(findViewById(R.id.serial_num))).getText().toString();

                temp=temp.trim();
                name=name.trim();
                email=email.trim();
                pw1=pw1.trim();
                pw=pw.trim();
                serial_num = serial_num.trim();

                if(name.equals(temp)||email.equals(temp)||pw1.equals(temp)||pw.equals(temp))
                {
                    handler.sendEmptyMessage(1);
                }
                else if(!pw1.equals(pw)) {
                    handler.sendEmptyMessage(2);
                }else if (pw1.length() < 8) {
                    handler.sendEmptyMessage(4);
                }
                else {
                    new HttpTask().execute();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    class HttpTask extends AsyncTask<Void, Void, String> { //서버에 보낼 로그인 정보 인자 전달함수(POST 방식)

        @Override
        protected String doInBackground(Void... voids) {
            // TODO Auto-generated method stub
            try{
                HttpPost request = new HttpPost("http://shuphin.cafe24.com/submit.php");
                //전달할 인자들
                Vector<NameValuePair> nameValue = new Vector<NameValuePair>();
                nameValue.add(new BasicNameValuePair("name", name));
                nameValue.add(new BasicNameValuePair("email", email));
                nameValue.add(new BasicNameValuePair("pw", pw));
                nameValue.add(new BasicNameValuePair("phone", phone));
                nameValue.add(new BasicNameValuePair("serial_num", serial_num));


                //웹 접속 - utf-8 방식으로
                HttpEntity enty = new UrlEncodedFormEntity(nameValue, HTTP.UTF_8);
                request.setEntity(enty);

                HttpClient client = new DefaultHttpClient();
                HttpResponse res = client.execute(request);
                //웹 서버에서 값받기
                HttpEntity entityResponse = res.getEntity();
                InputStream im = entityResponse.getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(im, HTTP.UTF_8));

                result = "";
                String tmp = "";
                //버퍼에있는거 전부 더해주기
                //readLine -> 파일내용을 줄 단위로 읽기
                while((tmp = reader.readLine())!= null)
                {
                    if(tmp != null)
                    {
                        result += tmp;
                    }
                }
                im.close();
                Log.d("Hello", result);


                //결과창뿌려주기 - ui 변경시 에러
                //result.setText(total);
                if(result.trim().equals("성공적으로 가입되었습니다."))
                {
                    handler.sendEmptyMessage(0);
                }
                else{
                    handler.sendEmptyMessage(3);
                }
                return result;
            }catch(UnsupportedEncodingException e){
                e.printStackTrace();
            }catch(IOException e){
                e.printStackTrace();
            }
            //오류시 null 반환
            return null;
        }
        //asyonTask 3번째 인자와 일치 매개변수값 -> doInBackground 리턴값이 전달됨
        //AsynoTask 는 preExcute - doInBackground - postExecute 순으로 자동으로 실행됩니다.
        //ui는 여기서 변경
        protected void onPostExecute(String value){
            super.onPostExecute(value);
        }
    }

    final Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg){
            switch (msg.what) {
                case 0:
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                            context);
                    // 제목셋팅
                    alertDialogBuilder.setTitle("알림");

                    // AlertDialog 셋팅
                    alertDialogBuilder
                            .setMessage(result)
                            .setCancelable(false)
                            .setNegativeButton("확인",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(
                                                DialogInterface dialog, int id) {
                                            // 다이얼로그를 취소한다
                                            dialog.cancel();
                                            Intent intent = new Intent(getApplicationContext(), Login2.class);
                                            intent.putExtra("mac","");
                                            startActivity(intent);
                                            finish();
                                        }
                                    });

                    // 다이얼로그 생성
                    AlertDialog alertDialog = alertDialogBuilder.create();

                    // 다이얼로그 보여주기
                    alertDialog.show();

                    break;
                case 1:
                    AlertDialog.Builder alertDialogBuilder2 = new AlertDialog.Builder(
                            context);
                    // 제목셋팅
                    alertDialogBuilder2.setTitle("알림");

                    // AlertDialog 셋팅
                    alertDialogBuilder2
                            .setMessage("모든칸을 입력하세요")
                            .setCancelable(false)
                            .setNegativeButton("확인",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(
                                                DialogInterface dialog, int id) {
                                            // 다이얼로그를 취소한다
                                            dialog.cancel();
                                            //Intent intent = new Intent(getApplicationContext(), SubActivity.class);
                                        }
                                    });

                    // 다이얼로그 생성
                    AlertDialog alertDialog2 = alertDialogBuilder2.create();

                    // 다이얼로그 보여주기
                    alertDialog2.show();

                    break;
                case 2:
                    AlertDialog.Builder alertDialogBuilder3 = new AlertDialog.Builder(
                            context);
                    // 제목셋팅
                    alertDialogBuilder3.setTitle("알림");

                    // AlertDialog 셋팅
                    alertDialogBuilder3
                            .setMessage("비밀번호가 일치하지 않습니다")
                            .setCancelable(false)
                            .setNegativeButton("확인",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(
                                                DialogInterface dialog, int id) {
                                            // 다이얼로그를 취소한다
                                            dialog.cancel();
                                            //Intent intent = new Intent(getApplicationContext(), SubActivity.class);
                                        }
                                    });

                    // 다이얼로그 생성
                    AlertDialog alertDialog3 = alertDialogBuilder3.create();

                    // 다이얼로그 보여주기
                    alertDialog3.show();

                    break;
                case 3:
                    AlertDialog.Builder alertDialogBuilder4 = new AlertDialog.Builder(
                            context);
                    // 제목셋팅
                    alertDialogBuilder4.setTitle("알림");

                    // AlertDialog 셋팅
                    alertDialogBuilder4
                            .setMessage(result)
                            .setCancelable(false)
                            .setNegativeButton("확인",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(
                                                DialogInterface dialog, int id) {
                                            // 다이얼로그를 취소한다
                                            dialog.cancel();
                                            //Intent intent = new Intent(getApplicationContext(), SubActivity.class);
                                        }
                                    });

                    // 다이얼로그 생성
                    AlertDialog alertDialog4 = alertDialogBuilder4.create();

                    // 다이얼로그 보여주기
                    alertDialog4.show();
                    break;
                case 4:
                    AlertDialog.Builder alertDialogBuilder5 = new AlertDialog.Builder(
                            context);
                    // 제목셋팅
                    alertDialogBuilder5.setTitle("알림");

                    // AlertDialog 셋팅
                    alertDialogBuilder5
                            .setMessage("비밀번호는 8자 이상이여야 합니다.")
                            .setCancelable(false)
                            .setNegativeButton("확인",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(
                                                DialogInterface dialog, int id) {
                                            // 다이얼로그를 취소한다
                                            dialog.cancel();
                                            //Intent intent = new Intent(getApplicationContext(), SubActivity.class);
                                        }
                                    });

                    // 다이얼로그 생성
                    AlertDialog alertDialog5 = alertDialogBuilder5.create();

                    // 다이얼로그 보여주기
                    alertDialog5.show();

                    break;
                default:
                    Toast toast = Toast.makeText(MemberJoin2.this, "정상적으로 로그인 되었습니다.", Toast.LENGTH_LONG);
                    toast.show();
                    Intent intent = new Intent(MemberJoin2.this, Login2.class);
                    startActivity(intent);
                    break;
            }
        }
    };

}