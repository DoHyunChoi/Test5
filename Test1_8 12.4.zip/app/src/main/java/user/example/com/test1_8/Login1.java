package user.example.com.test1_8;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

import static user.example.com.test1_8.R.id.btn_login;
import static user.example.com.test1_8.R.id.btn_signup;


/**
 * Created by dohyun on 2016-10-25.
 */


public class Login1 extends AppCompatActivity {

    private static final String TAG = "Login1";
    private static final int REQUEST_SIGNUP = 0;
    final Context context = this;
    String result = ""; //서버에서 성공적으로 가입했는지 확인
    String email = "";
    String pw1 = "";

    private BackPressCloseHandler backPressCloseHandler;

   // String tvon = DateFormat.getDateTimeInstance().format(new Date());
    long onnow = System.currentTimeMillis();
    Date date = new Date(onnow);
    SimpleDateFormat sdfNow = new SimpleDateFormat("yyyyMMdd HHmmss");
    String tvon = sdfNow.format(date);




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        findViewById(btn_login).setOnClickListener(button_login);
        findViewById(btn_signup).setOnClickListener(button_signup);
        TextView textView = (TextView)findViewById(R.id.textTimeView);
        //email = String.valueOf((EditText) findViewById(R.id.email));
        email=((EditText)(findViewById(R.id.email))).getText().toString();
        pw1 = ((EditText)(findViewById(R.id.pw1))).getText().toString();
        /// /pw1 = String.valueOf((EditText) findViewById(R.id.pw1));

        Intent intent = getIntent();

        //System.out.println(currentDateTimeString);
       // textTimeView.setText(currentDateTimeString);
        try {
            new writeTimeTask().execute();
            textView.setText(tvon);
        }
       catch (Exception e)
       {

       }



        //intent.putExtra(currentDateTimeString,currentDateTimeString);
        backPressCloseHandler = new BackPressCloseHandler(this);

    }
    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        backPressCloseHandler.onBackPressed();

    }

    Button.OnClickListener button_login = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {

            Intent intentontv = new Intent(getApplicationContext(),TVActivity.class);
            intentontv.putExtra("tvon",tvon);

            //startActivity(intentontv);




            if(((EditText)(findViewById(R.id.email))).getText().toString().length() == 0)
            {
                AlertDialog.Builder builder = new AlertDialog.Builder(Login1.this); // AlertDialog를 띄울 activity를 argument로 지정해야 한다.
                builder.setTitle("올바른 이메일을 입력하세요"); // AlertDialog.builder를 통해 Title text를 입력
                builder.setPositiveButton("다시 작성하기", new DialogInterface.OnClickListener() { // AlertDialog.Builder에 Positive Button을 생성
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //  returnVal.setText("앱을 종료하지 않고 돌아왔음");
                        dialog.dismiss(); // "아니오" button이 받은 DialogInterface를 dismiss 하여 MainView로 돌아감
                    }
                });
                AlertDialog dialog = builder.create(); // 위의 builder를 생성할 AlertDialog 객체 생성
                dialog.show(); // dialog를 화면에 뿌려 줌
            }
            else if(((EditText)(findViewById(R.id.pw1))).getText().toString().length()< 8)
            {
                AlertDialog.Builder builder = new AlertDialog.Builder(Login1.this); // AlertDialog를 띄울 activity를 argument로 지정해야 한다.
                builder.setTitle("올바른 비밀번호를 입력하세요 (영문혼합 8자리 이상이여야 합니다)"); // AlertDialog.builder를 통해 Title text를 입력
                builder.setPositiveButton("다시 작성하기", new DialogInterface.OnClickListener() { // AlertDialog.Builder에 Positive Button을 생성
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //  returnVal.setText("앱을 종료하지 않고 돌아왔음");
                        dialog.dismiss(); // "아니오" button이 받은 DialogInterface를 dismiss 하여 MainView로 돌아감
                    }
                });
                AlertDialog dialog = builder.create(); // 위의 builder를 생성할 AlertDialog 객체 생성
                dialog.show(); // dialog를 화면에 뿌려 줌
            }
            else {
                Toast toast = Toast.makeText(Login1.this, "정상적으로 로그인 되었습니다.", Toast.LENGTH_LONG);
                toast.show();
                Intent intent = new Intent(getApplicationContext(), Login2.class);
                startActivityForResult(intent, REQUEST_SIGNUP);
                finish();

            }
        }

    };
    Button.OnClickListener button_signup = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {
            // Start the Signup activity
            Intent intent = new Intent(getApplicationContext(), MemberJoin2.class);
            startActivityForResult(intent, REQUEST_SIGNUP);
            finish();
        }
    };












    class writeTimeTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            // TODO Auto-generated method stub
            try{
                HttpPost request = new HttpPost("http://shuphin.cafe24.com/wwrite.php");
                //전달할 인자들
                Vector<NameValuePair> nameValue = new Vector<NameValuePair>();
                nameValue.add(new BasicNameValuePair("tvon", tvon));

                //웹 접속 - utf-8 방식으로
                HttpEntity enty = new UrlEncodedFormEntity(nameValue, HTTP.UTF_8);
                request.setEntity(enty);

                HttpClient client = new DefaultHttpClient();
                HttpResponse res = client.execute(request);
                //웹 서버에서 값받기
                HttpEntity entityResponse = res.getEntity();
                InputStream im = entityResponse.getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(im, HTTP.UTF_8));

                String result = "";
                String tmp = "";
                //버퍼에있는거 전부 더해주기
                //readLine -> 파일내용을 줄 단위로 읽기
                while((tmp = reader.readLine())!= null)
                {
                    if(tmp != null)
                    {
                        result += tmp;
                    }
                }
                im.close();
                Log.d("Hello", result);
                result = result.trim();
                return result;
            }catch(UnsupportedEncodingException e){
                e.printStackTrace();
            }catch(IOException e){
                e.printStackTrace();
            }
            //오류시 null 반환
            return null;
        }
        //asyonTask 3번째 인자와 일치 매개변수값 -> doInBackground 리턴값이 전달됨
        //AsynoTask 는 preExcute - doInBackground - postExecute 순으로 자동으로 실행됩니다.
        //ui는 여기서 변경
        protected void onPostExecute(String value){
            super.onPostExecute(value);
        }

    }
}