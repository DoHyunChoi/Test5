package user.example.com.test1_8;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;

/**
 * Created by user on 2016-11-23.
 */

public class Display extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstaceState)
    {
        super.onCreate(savedInstaceState);
        setContentView(R.layout.activity_web);
        webView = (WebView)findViewById(R.id.webView);
        webView.loadUrl("http://shuphin.cafe24.com/uploads/upload.php");

    }


}
