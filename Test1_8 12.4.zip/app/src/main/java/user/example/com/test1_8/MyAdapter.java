package user.example.com.test1_8;

/**
 * Created by dohyun on 2016-11-23.
 */



import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

public class MyAdapter extends ArrayAdapter<String> {
    private final Context context;
    private final String[] values;


    public MyAdapter(Context context, String[] values) {
        super(context, R.layout.list_item, values);
        this.context = context;
        this.values = values;

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos = position;

        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View itemView = inflater.inflate(R.layout.list_item, parent, false);
        //TextView textView = (TextView) itemView.findViewById(R.id.fname);
        //textView.setText(values[position]);

        return itemView;
    }


}