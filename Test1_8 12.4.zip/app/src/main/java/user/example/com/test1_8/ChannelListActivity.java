package user.example.com.test1_8;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import static user.example.com.test1_8.R.id.updatech;

/**
 * Created by user on 2016-11-16.
 */

public class ChannelListActivity extends AppCompatActivity implements View.OnClickListener {

    ImageView mImageView;
    //Bitmap mBmp = null;
    //Button channelListButton;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.channel_layout);

        mImageView = (ImageView) findViewById(R.id.imgTranslate);

        Button channel_btn = (Button) findViewById(R.id.channelListButton);
        channel_btn.setOnClickListener(this);
        Button updatech = (Button)findViewById(R.id.updatech);
        updatech.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        /*switch (v.getId()) {
            case R.id.channelListButton:
                // 1번째 버튼의 이벤트 함수
                Picasso.with(this).load("http://shuphin.cafe24.com/uploads/channel1.png").fit().into(mImageView);
                break;

            case R.id.updatech:
                Picasso.with(this).load("http://shuphin.cafe24.com/uploads/channel2.png").fit().into(mImageView);
                break;
        }*/
        if(v.getId()==R.id.channelListButton)
            Picasso.with(this).load("http://shuphin.cafe24.com/uploads/channel1.png").fit().into(mImageView);

        else if(v.getId()== updatech)
            Picasso.with(this).load("http://shuphin.cafe24.com/uploads/channel2.png").fit().into(mImageView);
        else{}

    }
}


