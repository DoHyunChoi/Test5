package user.example.com.test1_8;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

import static user.example.com.test1_8.R.id.button_offtv;

/**
 * Created by user on 2016-10-04.
 */

public class Login2 extends AppCompatActivity implements View.OnClickListener {
    private static final int REQUEST_SIGNUP = 0;

    private BackPressCloseHandler backPressCloseHandler;
    String tvoff = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);
        ImageButton tv_btn = (ImageButton) findViewById(R.id.imageButton5);
        ImageButton camera_btn = (ImageButton) findViewById(R.id.imageButton2);
        ImageButton channel_btn = (ImageButton) findViewById(R.id.imageButton3);
        ImageButton harm_btn = (ImageButton) findViewById(R.id.imageButton4);
        Button button_logout = (Button) findViewById(R.id.button_logout);
        Button button_offtv = (Button)findViewById(R.id.button_offtv);
        tv_btn.setOnClickListener(this);
        camera_btn.setOnClickListener(this);
        channel_btn.setOnClickListener(this);
        harm_btn.setOnClickListener(this);
        button_logout.setOnClickListener(this);
        button_offtv.setOnClickListener(this);

        backPressCloseHandler = new BackPressCloseHandler(this);
    }
    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        backPressCloseHandler.onBackPressed();
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imageButton5:
                Intent intent = new Intent(Login2.this, TVActivity.class);
                startActivity(intent);
                break;
            case R.id.imageButton2:
                Intent intent2 = new Intent(Login2.this, CameraActivity.class);
                startActivity(intent2);
                break;
            case R.id.imageButton3:
                Intent intent3 = new Intent(Login2.this, ChannelListActivity.class);
                startActivity(intent3);
                break;
            case R.id.imageButton4:
                Intent intent4 = new Intent(Login2.this, AlarmingActivity.class);
                startActivity(intent4);
                break;
            case R.id.button_logout:

                AlertDialog.Builder builder = new AlertDialog.Builder(Login2.this); // AlertDialog를 띄울 activity를 argument로 지정해야 한다.
                builder.setTitle("정말로 로그아웃 하실 겁니까?"); // AlertDialog.builder를 통해 Title text를 입력
                builder.setPositiveButton("네", new DialogInterface.OnClickListener() { // AlertDialog.Builder에 Positive Button을 생성
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(getApplicationContext(), Login1.class);
                        startActivityForResult(intent, REQUEST_SIGNUP);
                        finish(); // App.의 종료. Activity 생애 주기 참고
                    }
                });
                builder.setNegativeButton("아니오", new DialogInterface.OnClickListener() { // AlertDialog.Builder에 Negative Button을 생성
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast toast = Toast.makeText(Login2.this, "앱을 종료하지 않고 돌아왔습니다.", Toast.LENGTH_LONG);
                        //  returnVal.setText("앱을 종료하지 않고 돌아왔음");
                        dialog.dismiss(); // "아니오" button이 받은 DialogInterface를 dismiss 하여 MainView로 돌아감
                        toast.show();
                    }
                });
                AlertDialog dialog = builder.create(); // 위의 builder를 생성할 AlertDialog 객체 생성
                dialog.show(); // dialog를 화면에 뿌려 줌

                //Intent intent = new Intent(getApplicationContext(), Login1.class);
                // startActivityForResult(intent, REQUEST_SIGNUP);
                // finish();
                break;
            case button_offtv:
                try{

                    new writeTask().execute();

                    Toast.makeText(getApplicationContext(), "TV전원종료중...", Toast.LENGTH_SHORT).show();
                    long offnow = System.currentTimeMillis();
                    Date date = new Date(offnow);
                    SimpleDateFormat sdfNow = new SimpleDateFormat("yyyyMMdd HHmmss");
                    tvoff = sdfNow.format(date);

                    new writeTimeTask().execute();

                }catch (Exception e) {
                }
                Toast.makeText(getApplicationContext(), "TV전원종료완료!!", Toast.LENGTH_LONG).show();

                //Intent intentofftv = new Intent(getApplication(),TVActivity.class);
                //intentofftv.putExtra("tvoff",tvoff);
                //startActivity(intentofftv);


                break;
            default:
                break;
        }










    }
    final Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg){
            switch (msg.what) {
                case 0:
                    // textView.setText("0");
                    break;
                case 1:
                    // textView.setText("1");
                    break;
                case 2:
                    //  textView.setText("2");
                    break;
                case 3:
                    // textView.setText("3");
                    break;
                case 4:
                    //textView.setText("4");
                    break;
                case 5:
                    //textView.setText("4");
                    break;
                case 6:
                    //textView.setText("4");
                    break;
                case 7:
                    try{
                        new readTask().execute();
                    }catch (Exception e) {
                    }
                    break;
            }
        }
    };
    class readTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            // TODO Auto-generated method stub

            try{
                HttpPost request = new HttpPost("http://shuphin.cafe24.com/shread.php");
                //전달할 인자들
                //Vector<NameValuePair> nameValue = new Vector<NameValuePair>();
                //nameValue.add(new BasicNameValuePair("id", id));

                //웹 접속 - utf-8 방식으로
                //HttpEntity enty = new UrlEncodedFormEntity(nameValue, HTTP.UTF_8);
                //request.setEntity(enty);

                HttpClient client = new DefaultHttpClient();
                HttpResponse res = client.execute(request);
                //웹 서버에서 값받기
                HttpEntity entityResponse = res.getEntity();
                InputStream im = entityResponse.getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(im, HTTP.UTF_8));

                String result = "";
                String tmp = "";
                //버퍼에있는거 전부 더해주기
                //readLine -> 파일내용을 줄 단위로 읽기
                while((tmp = reader.readLine())!= null)
                {
                    if(tmp != null)
                    {
                        result += tmp;
                    }
                }
                im.close();
                Log.d("Hello", result);
                result = result.trim();


                switch (result) {
                    case "0" :
                        handler.sendEmptyMessage(0);
                        break;
                    case "1" :
                        handler.sendEmptyMessage(1);
                        break;
                    case "2" :
                        handler.sendEmptyMessage(2);
                        break;
                    case "3" :
                        handler.sendEmptyMessage(3);
                        break;
                    case "4" :
                        handler.sendEmptyMessage(4);
                        break;

                    case "5" :
                        handler.sendEmptyMessage(5);
                        break;

                    case "6" :
                        handler.sendEmptyMessage(6);
                        break;
                }





                return result;
            }catch(UnsupportedEncodingException e){
                e.printStackTrace();
            }catch(IOException e){
                e.printStackTrace();
            }
            //오류시 null 반환
            return null;
        }
        //asyonTask 3번째 인자와 일치 매개변수값 -> doInBackground 리턴값이 전달됨
        //AsynoTask 는 preExcute - doInBackground - postExecute 순으로 자동으로 실행됩니다.
        //ui는 여기서 변경
        protected void onPostExecute(String value){
            super.onPostExecute(value);
        }
    }
    class writeTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            // TODO Auto-generated method stub
            try{
                HttpPost request = new HttpPost("http://shuphin.cafe24.com/shwrite.php");
                //전달할 인자들
                Vector<NameValuePair> nameValue = new Vector<NameValuePair>();
                nameValue.add(new BasicNameValuePair("signal", String.valueOf(1)));

                //웹 접속 - utf-8 방식으로
                HttpEntity enty = new UrlEncodedFormEntity(nameValue, HTTP.UTF_8);
                request.setEntity(enty);

                HttpClient client = new DefaultHttpClient();
                HttpResponse res = client.execute(request);
                //웹 서버에서 값받기
                HttpEntity entityResponse = res.getEntity();
                InputStream im = entityResponse.getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(im, HTTP.UTF_8));

                String result = "";
                String tmp = "";
                //버퍼에있는거 전부 더해주기
                //readLine -> 파일내용을 줄 단위로 읽기
                while((tmp = reader.readLine())!= null)
                {
                    if(tmp != null)
                    {
                        result += tmp;
                    }
                }
                im.close();
                result = result.trim();
                handler.sendEmptyMessage(7);
                return result;
            }catch(UnsupportedEncodingException e){
                e.printStackTrace();
            }catch(IOException e){
                e.printStackTrace();
            }
            //오류시 null 반환
            return null;
        }
        //asyonTask 3번째 인자와 일치 매개변수값 -> doInBackground 리턴값이 전달됨
        //AsynoTask 는 preExcute - doInBackground - postExecute 순으로 자동으로 실행됩니다.
        //ui는 여기서 변경
        protected void onPostExecute(String value){
            super.onPostExecute(value);
        }
    }
    class writeTimeTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            // TODO Auto-generated method stub
            try{
                HttpPost request = new HttpPost("http://shuphin.cafe24.com/wwrite2.php");
                //전달할 인자들
                Vector<NameValuePair> nameValue = new Vector<NameValuePair>();
                nameValue.add(new BasicNameValuePair("tvoff", tvoff));

                //웹 접속 - utf-8 방식으로
                HttpEntity enty = new UrlEncodedFormEntity(nameValue, HTTP.UTF_8);
                request.setEntity(enty);

                HttpClient client = new DefaultHttpClient();
                HttpResponse res = client.execute(request);
                //웹 서버에서 값받기
                HttpEntity entityResponse = res.getEntity();
                InputStream im = entityResponse.getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(im, HTTP.UTF_8));

                String result = "";
                String tmp = "";
                //버퍼에있는거 전부 더해주기
                //readLine -> 파일내용을 줄 단위로 읽기
                while((tmp = reader.readLine())!= null)
                {
                    if(tmp != null)
                    {
                        result += tmp;
                    }
                }
                im.close();
                Log.d("Hello", result);
                result = result.trim();
                return result;
            }catch(UnsupportedEncodingException e){
                e.printStackTrace();
            }catch(IOException e){
                e.printStackTrace();
            }
            //오류시 null 반환
            return null;
        }
        //asyonTask 3번째 인자와 일치 매개변수값 -> doInBackground 리턴값이 전달됨
        //AsynoTask 는 preExcute - doInBackground - postExecute 순으로 자동으로 실행됩니다.
        //ui는 여기서 변경
        protected void onPostExecute(String value){
            super.onPostExecute(value);
        }

    }
}


