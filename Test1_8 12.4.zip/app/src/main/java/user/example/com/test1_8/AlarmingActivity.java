package user.example.com.test1_8;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Vector;


/**
 * Created by user on 2016-11-16.
 */

public class AlarmingActivity extends AppCompatActivity {


    private NotificationManager notificationManager; //상단바에 알림메세지 띄우기 위해서
    private static final int NOTIFICATION_ID = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alarming_layout);

        //Button button4 = (Button)findViewById(R.id.button4);
        //findViewById(btn_signup).setOnClickListener(button_signup);
        findViewById(R.id.btn_alarm).setOnClickListener(button4);

    }




    Button.OnClickListener button4 = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {
            final CharSequence[] items = {"7세미만", "7세이상 12세미안", "12세이상 15세미만"};

            AlertDialog.Builder builder = new AlertDialog.Builder(AlarmingActivity.this);     // 여기서 this는 Activity의 this

            // 여기서 부터는 알림창의 속성 설정
            builder.setTitle("아이의 나이대를 클릭하세요")        // 제목 설정
                    .setItems(items, new DialogInterface.OnClickListener(){    // 목록 클릭시 설정
                        public void onClick(DialogInterface dialog, int index){
                            Toast.makeText(getApplicationContext(), items[index]+"으로 설정하셨습니다.", Toast.LENGTH_SHORT).show();

                            Toast.makeText(getApplicationContext(), "알람전송중!!", Toast.LENGTH_LONG).show();
                            generatNotificaion();
                            if(index==0)
                            {
                                new writeTask5().execute();
                                Toast.makeText(getApplicationContext(), "7세미만 채널로 바꾸었습니다. ", Toast.LENGTH_LONG).show();
                            }
                            else if(index==1)
                            {
                                new writeTask6().execute();
                                Toast.makeText(getApplicationContext(), "12세미만 채널로 바꾸었습니다. ", Toast.LENGTH_LONG).show();
                            }
                            else
                            {

                            }

                        }
                    });

            AlertDialog dialog = builder.create();    // 알림창 객체 생성
            dialog.show();    // 알림창 띄우기


        }
    };

    private void generatNotificaion() {
        notificationManager = (NotificationManager)
                getSystemService(Context.NOTIFICATION_SERVICE);

        Context context = AlarmingActivity.this;
        Notification notify = new Notification.Builder(context)
                .setTicker("Warning!! from KOT")
                .setContentTitle("TV를 종료해주세요!!")
                .setContentText("아이의 유해매체 시청이 감지되었습니다ㅜㅜ")
                .setSmallIcon(android.R.drawable.stat_notify_more)
                .setWhen(System.currentTimeMillis())
                .build();
        notificationManager.notify(NOTIFICATION_ID, notify);
    }

    final Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg){
            switch (msg.what) {
                case 0:
                    // textView.setText("0");
                    break;
                case 1:
                    // textView.setText("1");
                    break;
                case 2:
                    //  textView.setText("2");
                    break;
                case 3:
                    // textView.setText("3");
                    break;
                case 4:
                    //textView.setText("4");
                    break;
                case 5:
                    //textView.setText("4");
                    break;
                case 6:
                    //textView.setText("4");
                    break;
                case 7:
                    try{
                        new readTask().execute();
                    }catch (Exception e) {
                    }
                    break;
            }
        }
    };
    class readTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            // TODO Auto-generated method stub

            try{
                HttpPost request = new HttpPost("http://shuphin.cafe24.com/shread.php");
                //전달할 인자들
                //Vector<NameValuePair> nameValue = new Vector<NameValuePair>();
                //nameValue.add(new BasicNameValuePair("id", id));

                //웹 접속 - utf-8 방식으로
                //HttpEntity enty = new UrlEncodedFormEntity(nameValue, HTTP.UTF_8);
                //request.setEntity(enty);

                HttpClient client = new DefaultHttpClient();
                HttpResponse res = client.execute(request);
                //웹 서버에서 값받기
                HttpEntity entityResponse = res.getEntity();
                InputStream im = entityResponse.getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(im, HTTP.UTF_8));

                String result = "";
                String tmp = "";
                //버퍼에있는거 전부 더해주기
                //readLine -> 파일내용을 줄 단위로 읽기
                while((tmp = reader.readLine())!= null)
                {
                    if(tmp != null)
                    {
                        result += tmp;
                    }
                }
                im.close();
                Log.d("Hello", result);
                result = result.trim();
                String name = result.split("/")[0];
                String tvon = result.split("/")[1];
                String tvonsplit = tvon .split(" ")[1];

                switch (name) {
                    case "0" :
                        handler.sendEmptyMessage(0);
                        break;
                    case "1" :
                        handler.sendEmptyMessage(1);
                        break;
                    case "2" :
                        handler.sendEmptyMessage(2);
                        break;
                    case "3" :
                        handler.sendEmptyMessage(3);
                        break;
                    case "4" :
                        handler.sendEmptyMessage(4);
                        break;

                    case "5" :
                        handler.sendEmptyMessage(5);
                        break;

                    case "6" :
                        handler.sendEmptyMessage(6);
                        break;
                }





                return result;
            }catch(UnsupportedEncodingException e){
                e.printStackTrace();
            }catch(IOException e){
                e.printStackTrace();
            }
            //오류시 null 반환
            return null;
        }
        //asyonTask 3번째 인자와 일치 매개변수값 -> doInBackground 리턴값이 전달됨
        //AsynoTask 는 preExcute - doInBackground - postExecute 순으로 자동으로 실행됩니다.
        //ui는 여기서 변경
        protected void onPostExecute(String value){
            super.onPostExecute(value);
        }
    }

    class writeTask5 extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            // TODO Auto-generated method stub
            try{
                HttpPost request = new HttpPost("http://shuphin.cafe24.com/shwrite.php");
                //전달할 인자들
                Vector<NameValuePair> nameValue = new Vector<NameValuePair>();
                nameValue.add(new BasicNameValuePair("signal", String.valueOf(5)));

                //웹 접속 - utf-8 방식으로
                HttpEntity enty = new UrlEncodedFormEntity(nameValue, HTTP.UTF_8);
                request.setEntity(enty);

                HttpClient client = new DefaultHttpClient();
                HttpResponse res = client.execute(request);
                //웹 서버에서 값받기
                HttpEntity entityResponse = res.getEntity();
                InputStream im = entityResponse.getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(im, HTTP.UTF_8));

                String result = "";
                String tmp = "";
                //버퍼에있는거 전부 더해주기
                //readLine -> 파일내용을 줄 단위로 읽기
                while((tmp = reader.readLine())!= null)
                {
                    if(tmp != null)
                    {
                        result += tmp;
                    }
                }
                im.close();
                result = result.trim();

                return result;
            }catch(UnsupportedEncodingException e){
                e.printStackTrace();
            }catch(IOException e){
                e.printStackTrace();
            }
            //오류시 null 반환
            return null;
        }
        //asyonTask 3번째 인자와 일치 매개변수값 -> doInBackground 리턴값이 전달됨
        //AsynoTask 는 preExcute - doInBackground - postExecute 순으로 자동으로 실행됩니다.
        //ui는 여기서 변경
        protected void onPostExecute(String value){
            super.onPostExecute(value);
        }
    }
    class writeTask6 extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            // TODO Auto-generated method stub
            try{
                HttpPost request = new HttpPost("http://shuphin.cafe24.com/shwrite.php");
                //전달할 인자들
                Vector<NameValuePair> nameValue = new Vector<NameValuePair>();
                nameValue.add(new BasicNameValuePair("signal", String.valueOf(6)));

                //웹 접속 - utf-8 방식으로
                HttpEntity enty = new UrlEncodedFormEntity(nameValue, HTTP.UTF_8);
                request.setEntity(enty);

                HttpClient client = new DefaultHttpClient();
                HttpResponse res = client.execute(request);
                //웹 서버에서 값받기
                HttpEntity entityResponse = res.getEntity();
                InputStream im = entityResponse.getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(im, HTTP.UTF_8));

                String result = "";
                String tmp = "";
                //버퍼에있는거 전부 더해주기
                //readLine -> 파일내용을 줄 단위로 읽기
                while((tmp = reader.readLine())!= null)
                {
                    if(tmp != null)
                    {
                        result += tmp;
                    }
                }
                im.close();
                result = result.trim();

                return result;
            }catch(UnsupportedEncodingException e){
                e.printStackTrace();
            }catch(IOException e){
                e.printStackTrace();
            }
            //오류시 null 반환
            return null;
        }
        //asyonTask 3번째 인자와 일치 매개변수값 -> doInBackground 리턴값이 전달됨
        //AsynoTask 는 preExcute - doInBackground - postExecute 순으로 자동으로 실행됩니다.
        //ui는 여기서 변경
        protected void onPostExecute(String value){
            super.onPostExecute(value);
        }
    }

}
